"""
You Won't Be Here Tomorrow – Pygame Edition
------------------------------------------------

This game is an extended version of the web‑based
prototype, built using the Pygame library.  It retains
the core mechanics of the original concept—each
character gets exactly one meaningful, irreversible
action—but expands the idea into a fuller 2D world
with pixel art assets, a larger map and more
interactivity.  The player moves a small avatar
around a top‑down map, physically walking to objects
and pressing the interact key to perform actions.

Characters
==========

* Caretaker: Can plant a tree, build a fence or leave
  a note at one of three markers.  After their
  action, the other two markers disappear.

* Survivor: Can build a shelter by repurposing a tree
  or fence left by the Caretaker.  If nothing is
  available, they simply leave.

* Historian: Can either record the current state of
  the world (interact with a book icon) or dismantle
  a shelter if one exists.  Only one action is
  permitted.

* Final Witness: Does not alter the world; they walk
  to the eye icon to finish the game.  At the end,
  a summary shows all persistent objects and a log
  of the decisions made by previous characters.

Controls
========

* Arrow keys or WASD – Move the avatar around the map
* E or Space – Interact when standing on an interactive
  object (markers, trees, fence, shelter, book, eye)
* Escape – Quit the game

Assets
======

The ``assets/`` folder contains small pixel art images
generated with the imagegen tool.  Each image is
automatically scaled to 64×64 pixels for a cohesive
look.  Feel free to replace these sprites with your
own artwork as you iterate on the project.  At
runtime, the grass tile is repeated across the
background to fill the map.

Usage
=====

Ensure ``pygame`` is installed in your Python environment:

.. code-block:: bash

    pip install pygame

Then run the game with:

.. code-block:: bash

    python game.py

This script does not require any command line
arguments.  It will open a window and begin the
first character's turn immediately.
"""

import os
import sys
import pygame
from pygame.locals import (
    QUIT,
    KEYDOWN,
    K_ESCAPE,
    K_SPACE,
    K_e,
    K_w,
    K_a,
    K_s,
    K_d,
    K_UP,
    K_DOWN,
    K_LEFT,
    K_RIGHT,
)


###############################################################################
# Configuration
###############################################################################

# Size of each tile in pixels.  All assets are scaled to this size.
TILE_SIZE = 64

# Dimensions of the map in tiles.  Feel free to adjust, but keep in mind
# that larger maps may require more artwork to avoid repetition.
MAP_WIDTH = 15
MAP_HEIGHT = 10

# Frames per second.  Movement and animations are based on this.
FPS = 60

# Colours
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
DARK_OVERLAY = (0, 0, 0, 180)


###############################################################################
# Helper functions
###############################################################################

def load_image(name: str) -> pygame.Surface:
    """Load an image from the assets folder and scale it to TILE_SIZE.

    Parameters
    ----------
    name : str
        The filename relative to ``assets/`` to load.

    Returns
    -------
    pygame.Surface
        The loaded and scaled sprite.
    """
    base_path = os.path.join(os.path.dirname(__file__), "assets")
    full_path = os.path.join(base_path, name)
    try:
        image = pygame.image.load(full_path).convert_alpha()
    except FileNotFoundError as e:
        raise SystemExit(f"Unable to load image '{name}' from assets: {e}")
    return pygame.transform.smoothscale(image, (TILE_SIZE, TILE_SIZE))


def draw_text(surface: pygame.Surface, text: str, x: int, y: int, font: pygame.font.Font,
              colour: tuple = WHITE, shadow: bool = False) -> None:
    """Draw text with optional shadow for better visibility.

    Parameters
    ----------
    surface : pygame.Surface
        The destination surface.
    text : str
        The text to render.
    x, y : int
        The top-left coordinates.
    font : pygame.font.Font
        The font to use.
    colour : tuple, optional
        The colour of the text.
    shadow : bool, optional
        Whether to draw a subtle shadow beneath the text.
    """
    if shadow:
        shadow_surf = font.render(text, True, BLACK)
        surface.blit(shadow_surf, (x + 2, y + 2))
    text_surf = font.render(text, True, colour)
    surface.blit(text_surf, (x, y))


###############################################################################
# World and entity classes
###############################################################################

class World:
    """Represents the persistent state of the game world.

    The world keeps track of all objects that carry across characters,
    such as trees, fences, notes, shelters and the record book.  It
    provides helper methods to modify and query these objects.
    """

    def __init__(self):
        # Mapping of (tile_x, tile_y) -> object type string
        self.objects = {}
        # History of player actions for the final summary
        self.history = []
        # Predefined position for the record book (historian's marker)
        self.record_pos = (MAP_WIDTH // 2, MAP_HEIGHT // 2)
        # Predefined position for the eye (final witness marker)
        self.eye_pos = (MAP_WIDTH - 2, 1)

    def add_object(self, pos: tuple, obj_type: str) -> None:
        """Add an object to the world at a given tile.

        If another object already exists at that position, it will be
        overwritten.
        """
        self.objects[pos] = obj_type

    def remove_object(self, pos: tuple) -> None:
        """Remove an object from the world if present."""
        self.objects.pop(pos, None)

    def get_object(self, pos: tuple) -> str | None:
        """Retrieve the object type at a tile, or None if empty."""
        return self.objects.get(pos)


class Player:
    """Represents the player's avatar.

    Handles movement, collision with map bounds and objects, and
    rendering.  The player does not store knowledge about current
    character or world state; these are handled by the game logic.
    """

    def __init__(self, image: pygame.Surface, start_pos: tuple):
        self.image = image
        self.pos = list(start_pos)  # [x, y] in tile coordinates
        self.pixel_pos = [self.pos[0] * TILE_SIZE, self.pos[1] * TILE_SIZE]
        self.speed = 4  # pixels per frame
        self.move_dir = [0, 0]

    def update(self, world: World) -> None:
        """Update the player's position based on movement direction."""
        # Compute tentative new pixel position
        new_x = self.pixel_pos[0] + self.move_dir[0] * self.speed
        new_y = self.pixel_pos[1] + self.move_dir[1] * self.speed
        # Constrain to map boundaries
        new_x = max(0, min(new_x, MAP_WIDTH * TILE_SIZE - TILE_SIZE))
        new_y = max(0, min(new_y, MAP_HEIGHT * TILE_SIZE - TILE_SIZE))
        # Update positions
        self.pixel_pos = [new_x, new_y]
        self.pos = [new_x // TILE_SIZE, new_y // TILE_SIZE]

    def render(self, surface: pygame.Surface) -> None:
        surface.blit(self.image, self.pixel_pos)


class Game:
    """Main game controller.

    Manages the Pygame loop, character turns, interactions and world
    persistence.  Each character's behaviour is encapsulated in its
    own method.  When all characters have played, the final summary
    overlay is displayed until the user quits.
    """

    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((MAP_WIDTH * TILE_SIZE, MAP_HEIGHT * TILE_SIZE))
        pygame.display.set_caption("You Won't Be Here Tomorrow – Pygame Edition")
        self.clock = pygame.time.Clock()
        # Load assets
        self.sprites = {
            'player': load_image('player.png'),
            'tree': load_image('tree.png'),
            'fence': load_image('fence.png'),
            'note': load_image('note.png'),
            'shelter': load_image('shelter.png'),
            'book': load_image('book.png'),
            'grass': load_image('grass.png')
        }
        # Grass tile is repeated across the map; pre‑create a surface to draw
        self.background = pygame.Surface(self.screen.get_size())
        for y in range(MAP_HEIGHT):
            for x in range(MAP_WIDTH):
                self.background.blit(self.sprites['grass'], (x * TILE_SIZE, y * TILE_SIZE))
        # Fonts
        self.ui_font = pygame.font.SysFont('arial', 20)
        self.title_font = pygame.font.SysFont('arial', 30, bold=True)
        # World state
        self.world = World()
        # Characters sequence and index
        self.characters = ['caretaker', 'survivor', 'historian', 'final']
        self.current_char_index = 0
        # Player object (repositioned each turn)
        self.player = Player(self.sprites['player'], (1, MAP_HEIGHT - 2))
        # Marker positions for caretaker's possible actions
        self.caretaker_markers = {
            (2, 2): 'tree',
            (MAP_WIDTH - 3, 2): 'fence',
            (MAP_WIDTH // 2, MAP_HEIGHT - 4): 'note'
        }
        # Game over flag
        self.show_summary = False

    # Character behaviour methods ################################################

    def caretaker_turn(self) -> None:
        """Handle the Caretaker's actions."""
        # Draw caretaker markers
        for pos, typ in self.caretaker_markers.items():
            sprite = self.sprites[typ]
            self.screen.blit(sprite, (pos[0] * TILE_SIZE, pos[1] * TILE_SIZE))
        # Display hint
        draw_text(self.screen, "Caretaker: Plant a tree, build a fence or leave a note.", 10, 10, self.ui_font, shadow=True)
        # Process interactions
        for event in pygame.event.get():
            if event.type == QUIT:
                self.quit()
            elif event.type == KEYDOWN:
                if event.key in (K_ESCAPE,):
                    self.quit()
                # Movement
                if event.key in (K_w, K_UP):
                    self.player.move_dir[1] = -1
                elif event.key in (K_s, K_DOWN):
                    self.player.move_dir[1] = 1
                elif event.key in (K_a, K_LEFT):
                    self.player.move_dir[0] = -1
                elif event.key in (K_d, K_RIGHT):
                    self.player.move_dir[0] = 1
                # Interaction
                elif event.key in (K_SPACE, K_e):
                    pos = tuple(self.player.pos)
                    if pos in self.caretaker_markers:
                        chosen = self.caretaker_markers[pos]
                        # Place the chosen object and remove all markers
                        self.world.add_object(pos, chosen)
                        self.world.history.append(f"Caretaker placed a {chosen} at {pos}")
                        self.caretaker_markers.clear()
                        self.end_turn()
            elif event.type == pygame.KEYUP:
                # Stop movement when key released
                if event.key in (K_w, K_UP, K_s, K_DOWN):
                    self.player.move_dir[1] = 0
                elif event.key in (K_a, K_LEFT, K_d, K_RIGHT):
                    self.player.move_dir[0] = 0
        # Ensure markers vanish once chosen
        if not self.caretaker_markers:
            # Move to next character if markers removed (handled in event)
            pass

    def survivor_turn(self) -> None:
        """Handle the Survivor's actions."""
        # Show instruction based on world state
        draw_text(self.screen, "Survivor: Build a shelter from a tree or fence.", 10, 10, self.ui_font, shadow=True)
        # Determine available interactions
        interactive_positions = {pos for pos, t in self.world.objects.items() if t in ('tree', 'fence')}
        # If nothing is available, allow leaving via a special marker
        if not interactive_positions:
            # Draw an exit sign at top‑left
            exit_pos = (0, 0)
            draw_text(self.screen, "Leave", exit_pos[0] * TILE_SIZE + 10, exit_pos[1] * TILE_SIZE + 10, self.ui_font)
            interactive_positions.add(exit_pos)
        # Draw interactive positions
        for pos in interactive_positions:
            pygame.draw.rect(self.screen, (255, 255, 0), (pos[0] * TILE_SIZE + 16, pos[1] * TILE_SIZE + 16, TILE_SIZE - 32, TILE_SIZE - 32), 2)
        # Event handling
        for event in pygame.event.get():
            if event.type == QUIT:
                self.quit()
            elif event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    self.quit()
                # Movement
                if event.key in (K_w, K_UP):
                    self.player.move_dir[1] = -1
                elif event.key in (K_s, K_DOWN):
                    self.player.move_dir[1] = 1
                elif event.key in (K_a, K_LEFT):
                    self.player.move_dir[0] = -1
                elif event.key in (K_d, K_RIGHT):
                    self.player.move_dir[0] = 1
                # Interaction
                elif event.key in (K_SPACE, K_e):
                    pos = tuple(self.player.pos)
                    if pos in interactive_positions:
                        obj = self.world.get_object(pos)
                        if obj in ('tree', 'fence'):
                            self.world.remove_object(pos)
                            self.world.add_object(pos, 'shelter')
                            self.world.history.append(f"Survivor built a shelter from a {obj} at {pos}")
                        else:
                            self.world.history.append("Survivor left without building a shelter")
                        self.end_turn()
            elif event.type == pygame.KEYUP:
                # Stop movement
                if event.key in (K_w, K_UP, K_s, K_DOWN):
                    self.player.move_dir[1] = 0
                elif event.key in (K_a, K_LEFT, K_d, K_RIGHT):
                    self.player.move_dir[0] = 0

    def historian_turn(self) -> None:
        """Handle the Historian's actions."""
        draw_text(self.screen, "Historian: Record the past or dismantle a shelter.", 10, 10, self.ui_font, shadow=True)
        # Determine interactive positions: book marker always available; shelters if any exist
        interactive_positions = set([self.world.record_pos])
        shelter_positions = {pos for pos, t in self.world.objects.items() if t == 'shelter'}
        interactive_positions.update(shelter_positions)
        # Draw markers
        for pos in interactive_positions:
            if pos == self.world.record_pos:
                # draw book sprite as marker
                self.screen.blit(self.sprites['book'], (pos[0] * TILE_SIZE, pos[1] * TILE_SIZE))
            else:
                # highlight shelters for dismantling
                pygame.draw.rect(self.screen, (255, 0, 255), (pos[0] * TILE_SIZE + 16, pos[1] * TILE_SIZE + 16, TILE_SIZE - 32, TILE_SIZE - 32), 2)
        # Event handling
        for event in pygame.event.get():
            if event.type == QUIT:
                self.quit()
            elif event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    self.quit()
                # Movement
                if event.key in (K_w, K_UP):
                    self.player.move_dir[1] = -1
                elif event.key in (K_s, K_DOWN):
                    self.player.move_dir[1] = 1
                elif event.key in (K_a, K_LEFT):
                    self.player.move_dir[0] = -1
                elif event.key in (K_d, K_RIGHT):
                    self.player.move_dir[0] = 1
                # Interaction
                elif event.key in (K_SPACE, K_e):
                    pos = tuple(self.player.pos)
                    if pos == self.world.record_pos:
                        # record history
                        self.world.history.append("Historian recorded the past")
                        self.end_turn()
                    elif pos in shelter_positions:
                        # dismantle shelter
                        self.world.remove_object(pos)
                        self.world.history.append(f"Historian dismantled the shelter at {pos}")
                        self.end_turn()
            elif event.type == pygame.KEYUP:
                # Stop movement
                if event.key in (K_w, K_UP, K_s, K_DOWN):
                    self.player.move_dir[1] = 0
                elif event.key in (K_a, K_LEFT, K_d, K_RIGHT):
                    self.player.move_dir[0] = 0

    def final_turn(self) -> None:
        """Handle the Final Witness's actions."""
        draw_text(self.screen, "Final Witness: Observe and finish your journey.", 10, 10, self.ui_font, shadow=True)
        # Draw eye marker
        eye_pos = self.world.eye_pos
        pygame.draw.circle(self.screen, (0, 255, 255), (eye_pos[0] * TILE_SIZE + TILE_SIZE // 2, eye_pos[1] * TILE_SIZE + TILE_SIZE // 2), TILE_SIZE // 3, 0)
        # Event handling
        for event in pygame.event.get():
            if event.type == QUIT:
                self.quit()
            elif event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    self.quit()
                # Movement
                if event.key in (K_w, K_UP):
                    self.player.move_dir[1] = -1
                elif event.key in (K_s, K_DOWN):
                    self.player.move_dir[1] = 1
                elif event.key in (K_a, K_LEFT):
                    self.player.move_dir[0] = -1
                elif event.key in (K_d, K_RIGHT):
                    self.player.move_dir[0] = 1
                # Interaction
                elif event.key in (K_SPACE, K_e):
                    pos = tuple(self.player.pos)
                    if pos == eye_pos:
                        # End the game and show summary
                        self.show_summary = True
                        self.end_turn(final=True)
            elif event.type == pygame.KEYUP:
                if event.key in (K_w, K_UP, K_s, K_DOWN):
                    self.player.move_dir[1] = 0
                elif event.key in (K_a, K_LEFT, K_d, K_RIGHT):
                    self.player.move_dir[0] = 0

    # End turn helper ###########################################################

    def end_turn(self, final: bool = False) -> None:
        """Advance to the next character and reset the player.

        Parameters
        ----------
        final : bool
            Whether this is the last character.  If so, no further
            characters are cycled and the summary will be shown.
        """
        if final:
            return
        self.current_char_index += 1
        # Bound the index
        if self.current_char_index >= len(self.characters):
            self.show_summary = True
        else:
            # Reset player position for the next character
            # Use different spawn points for variety
            spawns = [
                (1, MAP_HEIGHT - 2),
                (MAP_WIDTH - 2, MAP_HEIGHT - 2),
                (1, 1),
                (MAP_WIDTH - 2, 1),
            ]
            self.player.pos = list(spawns[self.current_char_index % len(spawns)])
            self.player.pixel_pos = [self.player.pos[0] * TILE_SIZE, self.player.pos[1] * TILE_SIZE]
            self.player.move_dir = [0, 0]

    # Rendering of persistent world ################################################

    def draw_world(self) -> None:
        """Render the persistent objects (trees, fences, notes, shelters)."""
        for (x, y), obj_type in self.world.objects.items():
            sprite = self.sprites.get(obj_type)
            if sprite:
                self.screen.blit(sprite, (x * TILE_SIZE, y * TILE_SIZE))

    # Main loop ##################################################################

    def run(self) -> None:
        """Run the Pygame main loop until the user quits."""
        while True:
            self.clock.tick(FPS)
            # Draw background
            self.screen.blit(self.background, (0, 0))
            # Draw persistent objects
            self.draw_world()
            # Determine which character is active
            if self.show_summary:
                self.draw_summary()
            else:
                current_char = self.characters[self.current_char_index]
                # Character logic draws its own markers and UI; we update player first
                self.player.update(self.world)
                # Render player before markers to appear on top
                self.player.render(self.screen)
                # Call the corresponding turn handler
                if current_char == 'caretaker':
                    self.caretaker_turn()
                elif current_char == 'survivor':
                    self.survivor_turn()
                elif current_char == 'historian':
                    self.historian_turn()
                elif current_char == 'final':
                    self.final_turn()
            # Update display
            pygame.display.flip()

    # Final summary ###############################################################

    def draw_summary(self) -> None:
        """Render the final summary screen."""
        # Darken the background
        overlay = pygame.Surface(self.screen.get_size(), pygame.SRCALPHA)
        overlay.fill(DARK_OVERLAY)
        self.screen.blit(overlay, (0, 0))
        # Title
        draw_text(self.screen, "What remains:", 40, 40, self.title_font)
        # List objects
        y_offset = 80
        if not self.world.objects:
            draw_text(self.screen, "Nothing.", 40, y_offset, self.ui_font)
            y_offset += 30
        else:
            for pos, typ in self.world.objects.items():
                draw_text(self.screen, f"{typ.title()} at {pos}", 40, y_offset, self.ui_font)
                y_offset += 24
        # Separator
        y_offset += 10
        pygame.draw.line(self.screen, WHITE, (30, y_offset), (self.screen.get_width() - 30, y_offset), 1)
        y_offset += 20
        # History
        draw_text(self.screen, "Your actions:", 40, y_offset, self.title_font)
        y_offset += 40
        if not self.world.history:
            draw_text(self.screen, "You left no mark.", 40, y_offset, self.ui_font)
        else:
            for entry in self.world.history:
                if y_offset > self.screen.get_height() - 40:
                    break
                draw_text(self.screen, entry, 40, y_offset, self.ui_font)
                y_offset += 24
        # Footer
        draw_text(self.screen, "Press ESC to quit", 40, self.screen.get_height() - 40, self.ui_font)
        # Event handling (limited to quitting)
        for event in pygame.event.get():
            if event.type == QUIT:
                self.quit()
            elif event.type == KEYDOWN and event.key in (K_ESCAPE,):
                self.quit()

    def quit(self) -> None:
        """Cleanly exit the game."""
        pygame.quit()
        sys.exit()


if __name__ == '__main__':
    game = Game()
    game.run()